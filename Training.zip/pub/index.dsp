<META http-equiv='Content-Type' content='text/html; charset=UTF-8'>
<HTML>

<BODY>
    <CENTER>
        <H1>
            <font face="Tahoma">Welcome to the Home Page for the Training Package.</font>
        </H1>
        <form action="result.dsp" method="post">
            <input type="text" name="num1">
            <input type="text" name="num2">
            <input type="submit" value="Submit">
        </form>
    </CENTER>
</BODY>

</HTML>