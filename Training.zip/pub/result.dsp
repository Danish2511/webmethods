<HTML>

<BODY>
    <h1>Test</h1>
    %invoke Training.v1.services:add%
    <h1>%value result%</h1>
    %endinvoke%
</BODY>

</HTML>