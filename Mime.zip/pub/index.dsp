<html>

<head>
	<h1>Upload File</h1>
</head>

<body>
	<form action="http://localhost:5555/invoke/Mime.v1.services:fileUpload" method="POST" enctype="multipart/form-data>
				<table>
					<tr>
						<td>Select Input File</td>
						<td><input type="file" name="fileName">
		</td>
		</tr>
		<tr>
			<td><input type="submit" value="Submit"></td>
		</tr>
		</table>
	</form>
</body>

</html>