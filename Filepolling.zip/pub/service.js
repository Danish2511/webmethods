app.service('myserv', function() {
          this.getServiceList = function () {
    return [];
}
this.getISEndpoint = function() { 
 return 'http://ThinkPad:5555/';
}
this.getAPIList = function() { 
 return [];
}
this.getCreatedTime = function() { 
 return "19-11-2024 23:08:47 IST";
}
this.getPackageInfo = function(){
 return{"packageName":"Filepolling","createdDate":"18-11-2024 22:51:01 IST","version":"1.0"};
}
});
