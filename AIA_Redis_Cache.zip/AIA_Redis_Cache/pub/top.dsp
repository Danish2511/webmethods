<html>

<head>
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
    <meta http-equiv="Expires" content="-1">
    <script src="csrf-guard.js"></script>
    <script>
        const randomVersion = Math.floor(Math.random() * 1000000);
        document.write('<link rel="stylesheet" type="text/css" href="top.css?v=' + randomVersion + '">');
    </script>
</head>

<body>
    <header class="aialogo" style="display: flex; align-items: center;">
        <img src="images/aialogo.png" alt="AIA" width="60px">
        <div id="content">
            <h1>Azure Redis Cache</h1>
        </div>
    </header>
</body>

</html>