<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        const randomVersion = Math.floor(Math.random() * 1000000);
        document.write('<link rel="stylesheet" type="text/css" href="webMethods.css?v=' + randomVersion + '">');
    </script>
</head>

<body onload="deleteMessage()">
    <div class="fixed">
        <h2>Cache Manager</h2>
        <ul>
            <li>
                <a onclick="downloadFile()" download="redis-config.json" title="Download Configuration File">Get latest
                    configuration file</a>
            </li>
            <li >
                <a href="createNewConnection.dsp">Create Cache Manager</a>
            </li>
        </ul>
    </div>
    <div class="form">
        <table id="connTable" class="tableView" width="80%">

            <tr>
                <td class="heading" colspan="4">Connections</td>
            </tr>

            <tr>
                <th width="30%">Name</th>
                <th width="10%">Edit</th>
                <th width="10%">View</th>
                <th width="10%">Delete</th>
            </tr>
            %invoke AIA_Redis_Cache.services.dsp:deleteConnection%
            %endinvoke%
            %invoke AIA_Redis_Cache.services.dsp:getConnectionDetails%
            %loop connections%
            <tr>
                <td>%value name%</td>
                <td style="text-align: center;"><a href="edit.dsp?name=%value name%"><img src="images/edit.png"
                            width="20px" title="Edit"></a></td>
                <td style="text-align: center;"><a href="view.dsp?name=%value name%"><img src="images/view.png"
                            width="20px" title="View"></a></td>
                <td style="text-align: center;"><a href="deleteConnection.dsp?name=%value name%"
                        onclick="return window.confirm('Are you sure want to delete connection ?');"><img
                            src="images/delete.png" width="20px" title="Delete"></a></td>
            </tr>
            %endloop%
            %endinvoke%
        </table>
    </div>
    <div id="pagination">
        <!-- Pagination buttons go here -->
    </div>
    <div id="delete-message">
        Deleted Successfully
    </div>
    <script>

        function downloadFile() {
            // Replace 'your-api-endpoint' with the actual endpoint of your API
            var apiEndpoint = '/invoke/AIA_Redis_Cache.services.dsp:getConnectionDetails';

            // Adding headers to the fetch request
            var headers = new Headers();
            headers.append('Accept', 'application/json');

            // Making a fetch request to the API with custom headers
            fetch(apiEndpoint, {
                method: 'GET',
                headers: headers,
            })
                .then(response => response.json())
                .then(data => {
                    // Creating a Blob with the JSON data
                    var blob = new Blob([JSON.stringify(data.connections, null, 2)], { type: 'application/json' });

                    // Creating a hidden link element
                    var link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    link.download = 'redis-config.json';

                    // Appending the link to the body
                    document.body.appendChild(link);

                    // Triggering the click event to start the download
                    link.click();

                    // Removing the link from the DOM
                    document.body.removeChild(link);
                })
                .catch(error => console.error('Error fetching data:', error));
        }

        function deleteMessage() {
            var deleteMessage = document.getElementById('delete-message');
            deleteMessage.style.display = 'block';

            setTimeout(function () {
                deleteMessage.style.display = 'none';
            }, 2000);
        }
    </script>
</body>

</html>