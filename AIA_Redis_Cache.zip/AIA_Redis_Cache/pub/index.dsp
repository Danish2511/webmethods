<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=11">
    <title>AIA Redis Cache</title>
    <LINK REL="SHORTCUT ICON" HREF="images/favicon.ico">
</head>
<frameset rows="100%,*" border=0>
    <frame src="/AIA_Redis_Cache/home.dsp">
</frameset>
</html>