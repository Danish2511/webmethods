<html>

<head>
    <script>
        const randomVersion = Math.floor(Math.random() * 1000000);
        document.write('<link rel="stylesheet" type="text/css" href="webMethods.css?v=' + randomVersion + '">');
        window.onload = function() {
        // Check if pwdTD element exists and is not empty, then mask the content
        var pwdTD = document.getElementById('pwdTD');
        if (pwdTD != null && pwdTD.innerHTML.trim() !== "") {
            pwdTD.innerHTML = "**********";
        }

        // Check if CKeyTD element exists and is not empty, then mask the content
        var CKeyTD = document.getElementById('CKeyTD');
        if (CKeyTD != null && CKeyTD.innerHTML.trim() !== "") {
            CKeyTD.innerHTML = "**********";
        }
    };
        
    </script>
</head>

<body>
    <div class="fixed">
        <h2>View Connection</h2>
        <ul>
            <li>
                <a href="redisConnection.dsp">Return to Cache Manager</a>
            </li>
        </ul>
    </div>
    <div class="form">
        <table class="tableView" width="100%">
            %invoke AIA_Redis_Cache.services.dsp:getConnectionDetails%
            <tr>
                <td class="heading" colspan="4">%value connection/name% - Properties</td>
            </tr>
            <tr style="color: #87027b;">
                <th style="text-align: center;">Key</th>
                <th style="text-align: center;">Value</th>
                <th style="text-align: center;">Key</th>
                <th style="text-align: center;">Value</th>
            </tr>
            <tbody>
                <tr>
                    <td class="align-right">Property Based</td>
                    <td>%value connection/settings/propertyBased%</td>
                    <td class="align-right">User Based Auth</td>
                    <td>%value connection/settings/userBasedAuth%</td>
                </tr>
                <tr>
                    <td class="align-right">Hostname</td>
                    <td>%value connection/settings/hostName%</td>
                    <td class="align-right">Username</td>
                    <td>%value connection/settings/userName%</td>
                </tr>
                <tr>
                    <td class="align-right">Password</td>
                    <td id="pwdTD">%value connection/settings/password%</td>
                    <td class="align-right">Cache Key</td>
                    <td id="CKeyTD">%value connection/settings/cacheKey%</td>
                </tr>
                <tr>
                    <td class="align-right">Hostname Property</td>
                    <td>%value connection/settings/hostNameProperty%</td>
                    <td class="align-right">Username Property</td>
                    <td>%value connection/settings/userNameProperty%</td>
                </tr>
                <tr>
                    <td class="align-right">Password Property</td>
                    <td>%value connection/settings/passwordProperty%</td>
                    <td class="align-right">Cache Key Property</td>
                    <td>%value connection/settings/cacheKeyProperty%</td>
                </tr>
                <tr>
                    <td class="align-right">Use SSL</td>
                    <td>%value connection/settings/useSSL%</td>
                    <td class="align-right">SSL Port</td>
                    <td>%value connection/settings/sslPort%</td>
                </tr>
                <tr>
                    <td class="align-right">Non SSL Port</td>
                    <td>%value connection/settings/nonSSLPort%</td>
                    <td class="align-right">Pool Max Idle</td>
                    <td>%value connection/settings/poolMaxIdle%</td>
                    
                </tr>
                <tr>
                    <td class="align-right">Pool Min Idle</td>
                    <td>%value connection/settings/poolMinIdle%</td>
                    <td class="align-right">Pool Max Total</td>
                    <td>%value connection/settings/poolMaxTotal%</td>
                </tr>
                <tr>
                    <td class="align-right">Pool Block When Exhausted</td>
                    <td>%value connection/settings/poolBlockWhenExhausted%</td>
                    <td class="align-right">Pool Max Wait (Milliseconds)</td>
                    <td>%value connection/settings/poolMaxWaitMillis%</td>
                </tr>
                <tr>
                    <td class="align-right">Connection Time (Milliseconds)</td>
                    <td>%value connection/settings/connectTimeMillis%</td>
                    <td class="align-right">Operation Timeout (Milliseconds)</td>
                    <td>%value connection/settings/operationTimeoutMillis%</td>
                </tr>
                %endinvoke%
            </tbody>
        </table>
    </div>
</body>

</html>