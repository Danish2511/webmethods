<html>

<head>
	<title>Redis Cache</title>
	<script>
        const randomVersion = Math.floor(Math.random() * 1000000);
        document.write('<link rel="stylesheet" type="text/css" href="stats.css?v=' + randomVersion + '">');
    </script>
</head>

<body>
	<div class="fixed">
		<h2>Statistics</h2>
	</div>

	<div class="form">
		<form id="myForm">
			<div class="select">
				<label>Select Cache Manager:</label>
				<select id="cacheManager" name="cacheManagerName">
					<option value="">Select</option>
					%invoke AIA_Redis_Cache.services.dsp:getCacheManagers%
					%loop cacheManagers%
					<option value=%value cacheManagers%>%value cacheManagers%</option>
					%endloop%
					%endinvoke%
				</select>
			</div>
		</form>
		<div id="latest" class="tabcontent">
			<h3>Redis Pool Usage Information</h3>
			%include pool-usage-frag.dsp%
			<!--<div style="display: flex; justify-content: space-between;">
				<div id="additionalDetails" style="display: none;">
					<p style="color: black;">
						This Pool configuration is based on the below Extended parameters set in
						Integration
						Server
						Administration page.<br>
					<ul>
						<li>watt.aia.redis.cache.connection.pool.maxTotal</li>
						<li>watt.aia.redis.cache.connection.pool.maxIdle</li>
						<li>watt.aia.redis.cache.connection.pool.minIdle</li>
						<li>watt.aia.redis.cache.connection.pool.maxWaitMillis</li>
						<li>watt.aia.redis.cache.connection.pool.blockWhenExhausted</li>
					</ul>
					<br>
					<b>Procedue to refresh Pool Configuration</b> (Follow below steps if you want to
					change
					pool
					configuration)<br>
					<ol>
						<li>Update Extended parameters values in IS Administration page.</li>
						<li>Come here and click on "Reset Pool" button to reflect the changes.</li>
					</ol>
					<br><br>
					<b>Note:</b> Below extended parameters are used for Redis Cache
					configuration.<br>
					<ul>
						<li>watt.aia.redis.cache.host</li>
						<li>watt.aia.redis.cache.cacheKey</li>
						<li>watt.aia.redis.cache.useSSL</li>
						<li>watt.aia.redis.cache.ssl.port (used if above useSSL parameter is true.)
						</li>
						<li>watt.aia.redis.cache.nonssl.port (used if above useSSL parameter is
							false.)</li>
						<li>watt.aia.redis.cache.connectTimeMillis</li>
					</ul>
					<br>
					If you have plan to change these Redis Cache configuration parameters, follow
					<b>Procedue to
						refresh Pool Configuration</b> mentioned above.<br>
					</p>
				</div>
			</div>-->
		</div>
		<div style="float: right; margin-right: 20px;">
			<!--<a id="expandButton" href="javascript:void(0);" class="pill-button" onclick="toggleDetails()">Expand</a>-->
			<a href="/invoke/AIA_Redis_Cache.services.dsp/reload" class="pill-button"
				onclick="return window.confirm('Configuration will be reloaded and all existing pool will be destroyed ?');">Reset
				Pool</a>
		</div>
	</div>
	<script>

		const form = document.getElementById('myForm');
		const cn = document.getElementById('cacheManager');

		// Add an event listener to the select element
		cn.addEventListener('change', function () {
			var selectedCN = this.value;
			localStorage.setItem('selectedCN', selectedCN);
			form.submit();
		});

		document.addEventListener('DOMContentLoaded', function () {
			var storedValue = localStorage.getItem('selectedCN');
			if (storedValue) {
				document.getElementById('cacheManager').value = storedValue;
				localStorage.removeItem('selectedCN');
			}
		});
		
	</script>
</body>

</html>