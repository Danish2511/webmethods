<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        const randomVersion = Math.floor(Math.random() * 1000000);
        document.write('<link rel="stylesheet" type="text/css" href="webMethods.css?v=' + randomVersion + '">');
    </script>
</head>

<body>
    <div class="fixed">
        <h2>Add Cache</h2>
    </div>
    <div class="formCK">
        <table class="tableView" width="50%">
            <form action="/invoke/AIA_Redis_Cache.services.dsp:put" method="post" target="hiddenFrame"
                onsubmit="showSuccessMessage()">
                <tr>
                    <td class="heading" colspan="2">Assign Input Values</td>
                </tr>
                <tr>
                    <td>Cache Manager</td>
                    <td>
                        <select name="cacheManagerName" id="cacheManagerName" style="width: 100%;">
                            <option value="">Select</option>
                            %invoke AIA_Redis_Cache.services.dsp:getCacheManagers%
                            %loop cacheManagers%
                            <option value=%value cacheManagers%>%value cacheManagers%</option>
                            %endloop%
                            %endinvoke%
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Cache Name</td>
                    <td>
                        <input type="text" id="cacheName" name="cacheName" placeholder="Enter Cache Name" style="width: 100%;">
                    </td>
                </tr>
                <tr>
                    <td>Key</td>
                    <td>
                        <input type="text" name="key" placeholder="Enter Key" style="width: 100%;" required>
                    </td>
                </tr>
                <tr>
                    <td>Value</td>
                    <td>
                        <input type="text" name="value" placeholder="Enter Value" style="width: 100%;" required>
                    </td>
                </tr>
                <tr>
                    <td class="action">
                        %invoke AIA_Redis_Cache.services.dsp:isAdminAccess%
                        %ifvar isAdminAccess equals('true')%
                        <button id="submitBtn" class="pill-button" type="submit" disabled>Submit</button>
                        %else%
                        <button class="pill-button" type="button" disabled>Submit</button>
                        %endif%
                        %endinvoke%
                    </td>
                </tr>
            </form>
        </table>
    </div>
    <div id="success-message">Saved Successfully</div>
    <iframe id="hiddenFrame" name="hiddenFrame" style="display: none;"></iframe>
    <script>
        function showSuccessMessage() {
            var successMessage = document.getElementById('success-message');
            successMessage.style.display = 'block';

            setTimeout(function () {
                successMessage.style.display = 'none';
                window.location.href = "addKey.dsp";
            }, 2000);
        }

        const cacheManagerName = document.getElementById('cacheManagerName');
        const cacheName = document.getElementById('cacheName');
        const submitBtn = document.getElementById('submitBtn');

        cacheManagerName.addEventListener("change", toggleSubmitButton);
        cacheName.addEventListener("change", toggleSubmitButton);
        function toggleSubmitButton() {
            if (cacheManagerName.value === '' || cacheName.value === '') {
                submitBtn.disabled = true;
            } else {
                submitBtn.disabled = false;
            }
        }
    </script>
</body>

</html>