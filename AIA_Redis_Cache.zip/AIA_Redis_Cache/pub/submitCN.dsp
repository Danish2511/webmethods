<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        const randomVersion = Math.floor(Math.random() * 1000000);
        document.write('<link rel="stylesheet" type="text/css" href="webMethods.css?v=' + randomVersion + '">');
    </script>
</head>

<body>
    <div class="fixed">
        <h2>Cache Names</h2>
    </div>
    <div class="formCN">
        <form id="myForm" action="submitCN.dsp" method="post">
            <div class="select">
                <label>Select Cache Manager:</label>
                <select id="cacheManager" name="cacheManagerName">
                    <option value="">Select</option>
                    %invoke AIA_Redis_Cache.services.dsp:getCacheManagers%
                    %loop cacheManagers%
                    <option value=%value cacheManagers%>%value cacheManagers%</option>
                    %endloop%
                    %endinvoke%
                </select>
            </div>
        </form>
        
            %invoke AIA_Redis_Cache.services.dsp:getServerProperty%
            %invoke AIA_Redis_Cache.services.dsp:getCacheNames%
            %ifvar host matches('wm-msr-mq*')%
                %include mq.dsp%
            %else%
                %include non-mq.dsp%
            %endif%
            %endinvoke%
            %endinvoke%
        
    </div>
    <div id="reload-message"></div>
    <div id="loader-container" style="display: none;">
        <div class="loader"></div>
        Fetching Data
    </div>
    <script>
        
        const form = document.getElementById('myForm');
		const cn = document.getElementById('cacheManager');

		// Add an event listener to the select element
		cn.addEventListener('change', function () {
			var selectedCN = this.value;
			localStorage.setItem('selectedCN', selectedCN);
			form.submit();
		});

		document.addEventListener('DOMContentLoaded', function () {
			var storedValue = localStorage.getItem('selectedCN');
			if (storedValue) {
				document.getElementById('cacheManager').value = storedValue;
				localStorage.removeItem('selectedCN');
			}
		});

        function reloadDataMQ(cacheManagerName, cacheName) {
            // Replace 'your-api-endpoint' with the actual endpoint of your API
            var cacheManagerName = cacheManagerName;
            var cacheName = cacheName;

            // Prepare your inputData object
            var inputData = {
                cacheManagerName: cacheManagerName,
                cacheName: cacheName
            };
            // Call the API using fetch
            fetch('/invoke/AIA_Common_MQ_V2.services:reloadData', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(inputData),
            })
                .then(response => response.json())
                .then(data => {
                    document.getElementById("reload-message").textContent = "Reloaded Successfully";
                    showSuccessMessage();
                })
                .catch(error => {
                    alert('Error:', error);
                })
                .finally(() => {
                    hideLoader(); // Hide the loader regardless of success or failure
                });
        }

        function reloadData(cacheManagerName, cacheName) {
            // Replace 'your-api-endpoint' with the actual endpoint of your API
            var cacheManagerName = cacheManagerName;
            var cacheName = cacheName;

            // Prepare your inputData object
            var inputData = {
                cacheManagerName: cacheManagerName,
                cacheName: cacheName
            };
            // Call the API using fetch
            fetch('/invoke/AIA_Redis_Cache.services.dsp:reloadData', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(inputData),
            })
                .then(response => response.json())
                .then(data => {
                    document.getElementById("reload-message").textContent = "Reloaded Successfully";
                    showSuccessMessage();
                })
                .catch(error => {
                    alert('Error:', error);
                })
                .finally(() => {
                    hideLoader(); // Hide the loader regardless of success or failure
                });
        }

        function showSuccessMessage() {
            var successMessage = document.getElementById('reload-message');
            successMessage.style.display = 'block';

            setTimeout(function () {
                successMessage.style.display = 'none';
                location.reload();
            }, 2000);
        }

        function confirmReload(cacheManagerName, cacheName) {
            var confirmation = confirm("Are you sure you want reload data?");
            if (confirmation) {
                showLoader();
                reloadData(cacheManagerName, cacheName);
            }
        }

        function confirmReloadMQ(cacheManagerName, cacheName) {
            var confirmation = confirm("Are you sure you want reload data?");
            if (confirmation) {
                showLoader();
                reloadDataMQ(cacheManagerName, cacheName);
            }
        }

        function showLoader() {
            document.getElementById("loader-container").style.display = "flex";
        }

        function hideLoader() {
            document.getElementById("loader-container").style.display = "none";
        }

    </script>
</body>

</html>