function showSuccessMessage() {
    var successMessage = document.getElementById('success-message');
    successMessage.style.display = 'block';

    setTimeout(function () {
        successMessage.style.display = 'none';
        window.location.href = "redisConnection.dsp";
    }, 2000);
}

function updateMessage() {
    var updateMessage = document.getElementById('update-message');
    updateMessage.style.display = 'block';

    setTimeout(function () {
        updateMessage.style.display = 'none';
        window.location.href = "redisConnection.dsp";
    }, 2000);
}

/*********************************************************************************************/

/*********************************************************************************************/

// For UserBasedAuth
//Radios
const useSSLTrue = document.getElementById('useSSLTrue');
const userBasedAuthTrue = document.getElementById('userBasedAuthTrue');
const propertyBasedTrue = document.getElementById('propertyBasedTrue');

const useSSLFalse = document.getElementById('useSSLFalse');
const userBasedAuthFalse = document.getElementById('userBasedAuthFalse');
const propertyBasedFalse = document.getElementById('propertyBasedFalse');
//Input boxes
const userName = document.getElementById('userName');
const password = document.getElementById("password");
const cacheKey = document.getElementById("cacheKey");
const hostName = document.getElementById("hostName");
const userNameProperty = document.getElementById("userNameProperty");
const passwordProperty = document.getElementById("passwordProperty");
const cacheKeyProperty = document.getElementById("cacheKeyProperty");
const hostNameProperty = document.getElementById("hostNameProperty");
const sslport = document.getElementById("sslPort");
const nonsslport = document.getElementById("nonSSLPort");



//Used in fetch URL
var useSSL;
var userBasedAuth;
var propertyBased;


function updateState() {

    if (useSSLTrue.checked) {
        sslport.disabled = false;
        nonsslport.disabled = true;
        nonsslport.value ='';
    }

    if (useSSLFalse.checked) {
        sslport.disabled = true;
        sslport.value = '';
        nonsslport.disabled = false;

    }

    if (userBasedAuthTrue.checked && propertyBasedTrue.checked) {
        userNameProperty.disabled = false;
        passwordProperty.disabled = false;
        hostNameProperty.disabled = false;
        cacheKeyProperty.disabled = true;
        userName.disabled = true;
        password.disabled = true;
        cacheKey.disabled = true;
        hostName.disabled = true;
        cacheKeyProperty.value = '';
        userName.value = '';
        password.value = '';
        cacheKey.value = '';
        hostName.value = '';
    }
    if (userBasedAuthFalse.checked && propertyBasedTrue.checked) {
        hostNameProperty.disabled = false;
        cacheKeyProperty.disabled = false;
        userNameProperty.disabled = true;
        passwordProperty.disabled = true;
        userName.disabled = true;
        password.disabled = true;
        cacheKey.disabled = true;
        hostName.disabled = true;
        userNameProperty.value = '';
        passwordProperty.value = '';
        userName.value = '';
        password.value = '';
        cacheKey.value = '';
        hostName.value = '';
    }
    if (propertyBasedFalse.checked && userBasedAuthTrue.checked) {
        userName.disabled = false;
        password.disabled = false;
        hostName.disabled = false;
        userNameProperty.disabled = true;
        passwordProperty.disabled = true;
        cacheKeyProperty.disabled = true;
        hostNameProperty.disabled = true;
        cacheKey.disabled = true;
        userNameProperty.value = '';
        passwordProperty.value = '';
        cacheKeyProperty.value = '';
        hostNameProperty.value = '';
        cacheKey.value = '';
    }

    if (propertyBasedFalse.checked && userBasedAuthFalse.checked) {
        cacheKey.disabled = false;
        hostName.disabled = false;
        userNameProperty.disabled = true;
        passwordProperty.disabled = true;
        cacheKeyProperty.disabled = true;
        hostNameProperty.disabled = true;
        userName.disabled = true;
        password.disabled = true;
        userNameProperty.value = '';
        passwordProperty.value = '';
        cacheKeyProperty.value = '';
        hostNameProperty.value = '';
        userName.value = '';
        password.value = '';
    }
}
updateState();
userBasedAuthTrue.addEventListener('change', function () {
    updateState();
});

userBasedAuthFalse.addEventListener('change', function () {
    updateState();
});


propertyBasedTrue.addEventListener('change', function () {
    updateState();
});

propertyBasedFalse.addEventListener('change', function () {
    updateState();
});

useSSLTrue.addEventListener('change', function () {
    updateState();
});

useSSLFalse.addEventListener('change', function () {
    updateState();
});