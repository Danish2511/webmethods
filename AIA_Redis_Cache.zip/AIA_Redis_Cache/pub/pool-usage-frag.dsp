%invoke AIA_Redis_Cache.services.dsp:poolInfo%

<div
	style="margin-top: 10px; margin-bottom: 20px; padding: 10px 40px; border-radius: 10px; border: 2px solid black; border-style: inset; display: flex; justify-content: space-between;">
	<div style="width: 50%">
		<p style="margin-left: 15px">Total Connections : <b>%value PoolDetails/total%</b></p>
		<p style="margin-left: 15px">Active Connections: <b>%value PoolDetails/active%</b></p>
		<p style="margin-left: 15px">Idle Connections: <b>%value PoolDetails/idle%</b></p>
		<p style="margin-left: 15px">No Of Waiters: <b>%value PoolDetails/waiters%</b></p>
	</div>
	<div style="width: 50%">
		<p>Maximum Total Connections: <b>%value PoolDetails/maxTotal%</b></p>
		<p>Maximum Idle Connections: <b>%value PoolDetails/maxIdle%</b></p>
		<p>Minimum Idle Connections: <b>%value PoolDetails/minIdle%</b></p>
	</div>
</div>

%endinvoke%