<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        const randomVersion = Math.floor(Math.random() * 1000000);
        document.write('<link rel="stylesheet" type="text/css" href="webMethods.css?v=' + randomVersion + '">');
    </script>
</head>

<body>
    <div class="fixed">
        <h2>Cache Keys</h2>
    </div>
    <div class="formCK">
        <table class="tableView" width="80%">
            <form action="keysList.dsp" method="post" target="keysList">
                <tr>
                    <td class="heading" colspan="2">Assign Input Values</td>
                </tr>
                <tr>
                    <td>Cache Manager</td>
                    <td>
                        <input type="text" name="cacheManagerName" required>
                    </td>
                </tr>
                <tr>
                    <td>Cache Name</td>
                    <td>
                        <input type="text" name="cacheName" required>
                    </td>
                </tr>
                <tr>
                    <td class="action">
                        <button class="pill-button" type="submit">Submit</button>
                    </td>
                </tr>
            </form>
        </table>
    </div>
</body>

</html>