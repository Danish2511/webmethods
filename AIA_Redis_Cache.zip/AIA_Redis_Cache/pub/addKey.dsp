<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        const randomVersion = Math.floor(Math.random() * 1000000);
        document.write('<link rel="stylesheet" type="text/css" href="webMethods.css?v=' + randomVersion + '">');
    </script>
</head>

<body>
    <div class="fixed">
        <h2>Add Key</h2>
    </div>
    <div class="formCK">
        <table class="tableView" width="50%">
            <form action="/invoke/AIA_Redis_Cache.services.dsp:put" method="post" target="hiddenFrame"
                onsubmit="showSuccessMessage()">
                <tr>
                    <td class="heading" colspan="2">Assign Input Values</td>
                </tr>
                <tr>
                    <td>Cache Manager</td>
                    <td>
                        <select name="cacheManagerName" id="cacheManagerName" style="width: 100%;">
                            <option value="">Select</option>
                            %invoke AIA_Redis_Cache.services.dsp:getCacheManagers%
                            %loop cacheManagers%
                            <option value=%value cacheManagers%>%value cacheManagers%</option>
                            %endloop%
                            %endinvoke%
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Cache Name</td>
                    <td>
                        <select name="cacheName" id="cacheName" style="width: 100%;" disabled>
                            <option value="">Select</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Key</td>
                    <td>
                        <input type="text" name="key" placeholder="Enter Key" style="width: 100%;" required>
                    </td>
                </tr>
                <tr>
                    <td>Value</td>
                    <td>
                        <input type="text" name="value" placeholder="Enter Value" style="width: 100%;" required>
                    </td>
                </tr>
                <tr>
                    <td class="action">
                        %invoke AIA_Redis_Cache.services.dsp:isAdminAccess%
                        %ifvar isAdminAccess equals('true')%
                        <button id="submitBtn" class="pill-button" type="submit" disabled>Submit</button>
                        %else%
                        <button class="pill-button" type="button" disabled>Submit</button>
                        %endif%
                        %endinvoke%
                    </td>
                </tr>
            </form>
        </table>
    </div>
    <div id="success-message">Saved Successfully</div>
    <iframe id="hiddenFrame" name="hiddenFrame" style="display: none;"></iframe>
    <script>

        const cacheManagerName = document.getElementById('cacheManagerName');
        const cacheName = document.getElementById('cacheName');
        const submitBtn = document.getElementById('submitBtn');


        cacheManagerName.addEventListener('change', function () {
            var selectedValue = this.value;
            localStorage.setItem('selectedValue', selectedValue);
            if (cacheManagerName.value === '') {
                document.getElementById('cacheName').value = '';
                document.getElementById('cacheName').disabled = true;
            }
            else {
                document.getElementById('cacheName').disabled = false;
                showCacheName(this.value);
            }
        });

        function showCacheName(cacheManagerName) {
            var cacheManagerName = cacheManagerName;
            var inputData = {
                cacheManagerName: cacheManagerName
            };
            fetch('/invoke/AIA_Redis_Cache.services.dsp:getCacheNames', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(inputData),
            })
                .then(response => response.json())
                .then(data => {
                    var selectElement = document.getElementById('cacheName');
                    selectElement.innerHTML = ''; // Clear existing options

                    // Add the first option as "Select" with null value
                    var defaultOption = document.createElement('option');
                    defaultOption.value = '';
                    defaultOption.textContent = 'Select';
                    selectElement.appendChild(defaultOption);
                    // Loop through cache names and create option elements
                    '%invoke AIA_Redis_Cache.services.dsp:getServerProperty%'
                    '%ifvar host matches(wm-msr-mq*)%'
                    data.cacheNames.forEach(cache => {
                        var option = document.createElement('option');
                        option.value = cache.cacheName;
                        option.textContent = cache.cacheName;
                        selectElement.appendChild(option);
                    });
                    '%else%'
                    data.cacheNames.forEach(cache => {
                        if (!/^MQ.*/.test(cache.cacheName)) {
                            var option = document.createElement('option');
                            option.value = cache.cacheName;
                            option.textContent = cache.cacheName;
                            selectElement.appendChild(option);
                        }
                    });
                    '%endif%'
                    '%endinvoke%'
                })
                .catch(error => {
                    alert("Please select the cache manager first");
                });
        }

        function showSuccessMessage() {
            var successMessage = document.getElementById('success-message');
            successMessage.style.display = 'block';

            setTimeout(function () {
                successMessage.style.display = 'none';
                window.location.href = "addKey.dsp";
            }, 2000);
        }

        cacheManagerName.addEventListener("change", toggleSubmitButton);
        cacheName.addEventListener("change", toggleSubmitButton);
        function toggleSubmitButton() {
            if (cacheManagerName.value === '' || cacheName.value === '') {
                submitBtn.disabled = true;
            } else {
                submitBtn.disabled = false;
            }
        }
    </script>
</body>

</html>