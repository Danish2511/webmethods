<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        const randomVersion = Math.floor(Math.random() * 1000000);
        document.write('<link rel="stylesheet" type="text/css" href="webMethods.css?v=' + randomVersion + '">');
    </script>
    <script src="scripts.js" defer></script>
</head>

<body>
    <div class="fixed">
        <h2>Create Cache Manager</h2>
        <ul>
            <li>
                <a href="redisConnection.dsp">Return to Cache Manager</a>
            </li>
        </ul>
    </div>
    <div class="form">
        <table class="tableView" width="100%">
            <tr>
                <td class="heading" colspan="4">Properties</td>
            </tr>
            <tr>
                <td class="align-right">Property Based</td>
                <td>
                    <label><input id="propertyBasedTrue" class="radioSelect" type="radio" name="propertyBased"
                            value="true" checked> true</label>
                    <label><input id="propertyBasedFalse" class="radioSelect" type="radio" name="propertyBased"
                            value="false"> false</label>
                </td>
                <td class="align-right">User Based Auth</td>
                <td>
                    <label><input id="userBasedAuthTrue" class="radioSelect" type="radio" name="userBasedAuth"
                            value="true" checked> true</label>
                    <label><input id="userBasedAuthFalse" class="radioSelect" type="radio" name="userBasedAuth"
                            value="false"> false</label>
                </td>
            </tr>
            <tr>
                <td class="align-right">Name</td>
                <td><input id="name" type="text" name="name" required></td>
                <td class="align-right">Host Name</td>
                <td><input id="hostName" type="text" name="hostName" required></td>
            </tr>
            <tr>
                <td class="align-right">Username</td>
                <td><input id="userName" type="text" name="userName" required></td>
                <td class="align-right">Password</td>
                <td><input id="password" type="password" name="password" required></td>
            </tr>
            <tr>
                <td class="align-right">Cache Key</td>
                <td><input id="cacheKey" type="password" name="cacheKey" required></td>
                <td class="align-right">Hostname Property</td>
                <td><input id="hostNameProperty" type="text" name="hostNameProperty" required></td>
            </tr>
            <tr>
                <td class="align-right">Username Property</td>
                <td><input id="userNameProperty" type="text" name="userNameProperty" required></td>
                <td class="align-right">Password Property</td>
                <td><input id="passwordProperty" type="text" name="passwordProperty" required></td>
            </tr>
            <tr>
                <td class="align-right">Cache Key Property</td>
                <td><input id="cacheKeyProperty" type="text" name="cacheKeyProperty" required></td>
                <td class="align-right">Use SSL</td>
                <td>
                    <label><input id="useSSLTrue" class="radioSelect" type="radio" name="useSSL" value="true" checked>
                        true</label>
                    <label><input id="useSSLFalse" class="radioSelect" type="radio" name="useSSL" value="false">
                        false</label>
                </td>
            </tr>
            <tr>
                <td class="align-right">SSL Port</td>
                <td><input id="sslPort" type="number" name="sslPort" required></td>
                <td class="align-right">Non SSL Port</td>
                <td><input id="nonSSLPort" type="number" name="nonSSLPort" required></td>
            </tr>
            <tr>
                <td class="align-right">Pool Max Idle</td>
                <td><input id="poolMaxIdle" type="number" name="poolMaxIdle" required></td>
                <td class="align-right">Pool Min Idle</td>
                <td><input id="poolMinIdle" type="number" name="poolMinIdle" required></td>
            </tr>
            <tr>
                <td class="align-right">Pool Max Total</td>
                <td><input id="poolMaxTotal" type="number" name="poolMaxTotal" required></td>
                <td class="align-right">Pool Block When Exhausted</td>
                <td>
                    <label><input id="poolBlockWhenExhaustedTrue" type="radio" class="radioSelect"
                            name="poolBlockWhenExhausted" value="true" checked> true</label>
                    <label><input id="poolBlockWhenExhaustedFalse" type="radio" class="radioSelect"
                            name="poolBlockWhenExhausted" value="false">
                        false</label>
                </td>
            </tr>
            <tr>
                <td class="align-right">Pool Max Wait (Milliseconds)</td>
                <td><input id="poolMaxWaitMillis" type="number" name="poolMaxWaitMillis" required></td>
                <td class="align-right">Connection Time (Milliseconds)</td>
                <td><input id="connectTimeMillis" type="number" name="connectTimeMillis" required></td>
            </tr>
            <tr>
                <td class="align-right">Operation Timeout (Milliseconds)</td>
                <td><input id="operationTimeoutMillis" type="number" name="operationTimeoutMillis" required></td>
            </tr>
        </table>
        <input class="pill-button" type="submit" onclick="handleClick()" value="Save">
    </div>
    <div id="success-message"></div>
    <script>
        var poolBlockWhenExhausted;
        document.getElementById('poolBlockWhenExhaustedTrue').addEventListener('change', function () {
            poolBlockWhenExhausted = this.value;
        });
        document.getElementById('poolBlockWhenExhaustedFalse').addEventListener('change', function () {
            poolBlockWhenExhausted = this.value;
        });


        function validateInputs() {
            // Get all enabled input fields using the input tag selector
            const inputFields = document.querySelectorAll('input:not([disabled])');

            // Check if any of the enabled input fields is empty
            for (const inputField of inputFields) {
                if (inputField.value.trim() === '') {
                    alert('Please provide all inputs');
                    return false; // Prevent the fetch if validation fails
                }
            }

            return true; // Proceed with the fetch if validation passes
        }


        function saveData() {
            // Retrieve values from all input fields
            var name = document.getElementById('name').value;
            var hostName = document.getElementById('hostName').value;

            if (document.getElementById('userBasedAuthTrue').checked) {
                userBasedAuth = document.getElementById('userBasedAuthTrue').value;
            } else {
                userBasedAuth = document.getElementById('userBasedAuthFalse').value;
            }

            var userName = document.getElementById('userName').value;
            var password = document.getElementById('password').value;
            var cacheKey = document.getElementById('cacheKey').value;

            if (document.getElementById('propertyBasedTrue').checked) {
                propertyBased = document.getElementById('propertyBasedTrue').value;
            } else {
                propertyBased = document.getElementById('propertyBasedFalse').value;
            }

            var userNameProperty = document.getElementById('userNameProperty').value;
            var passwordProperty = document.getElementById('passwordProperty').value;
            var cacheKeyProperty = document.getElementById('cacheKeyProperty').value;
            var hostNameProperty = document.getElementById('hostNameProperty').value;

            if (document.getElementById('useSSLTrue').checked) {
                useSSL = document.getElementById('useSSLTrue').value;
            } else {
                useSSL = document.getElementById('useSSLFalse').value;
            }

            var sslPort = parseInt(document.getElementById('sslPort').value);
            var nonSSLPort = parseInt(document.getElementById('nonSSLPort').value);
            var connectTimeMillis = parseInt(document.getElementById('connectTimeMillis').value);
            var operationTimeoutMillis = parseInt(document.getElementById('operationTimeoutMillis').value);
            var poolMaxTotal = parseInt(document.getElementById('poolMaxTotal').value);
            var poolMaxIdle = parseInt(document.getElementById('poolMaxIdle').value);
            var poolMinIdle = parseInt(document.getElementById('poolMinIdle').value);

            if (document.getElementById('poolBlockWhenExhaustedTrue').checked) {
                poolBlockWhenExhausted = document.getElementById('poolBlockWhenExhaustedTrue').value;
            } else {
                poolBlockWhenExhausted = document.getElementById('poolBlockWhenExhaustedFalse').value;
            }

            var poolMaxWaitMillis = parseInt(document.getElementById('poolMaxWaitMillis').value);

            var inputData = {
                name: name,
                userName: userName,
                password: password,
                hostName: hostName,
                cacheKey: cacheKey,
                userBasedAuth: userBasedAuth === "true",
                userNameProperty: userNameProperty,
                passwordProperty: passwordProperty,
                cacheKeyProperty: cacheKeyProperty,
                hostNameProperty: hostNameProperty,
                propertyBased: propertyBased === "true",
                useSSL: useSSL === "true",
                sslPort: sslPort,
                nonSSLPort: nonSSLPort,
                connectTimeMillis: connectTimeMillis,
                operationTimeoutMillis: operationTimeoutMillis,
                poolMaxTotal: poolMaxTotal,
                poolMaxIdle: poolMaxIdle,
                poolMinIdle: poolMinIdle,
                poolBlockWhenExhausted: poolBlockWhenExhausted === "true",
                poolMaxWaitMillis: poolMaxWaitMillis
            };

            fetch('/invoke/AIA_Redis_Cache.services.dsp:addNewConnection', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(inputData),
            })
                .then(response => response.json())
                .then(data => {
                    document.getElementById("success-message").textContent= data.status;
                    showSuccessMessage();
                })
                .catch(error => {
                    alert('Error:', error);
                });
        }


        function handleClick() {
            // Validate inputs before initiating the fetch
            if (validateInputs()) {
                // Proceed with the fetch
                saveData();
            }
        }
    </script>
</body>

</html>