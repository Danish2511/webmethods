%invoke AIA_Redis_Cache.services.dsp:isAdminAccess%
%ifvar isAdminAccess equals('true')%
%ifvar cacheManagerName equals('EIPCommonCache')%
<table id="tblCN" class="tableView" width="100%">
            <tr>
                <td class="heading" colspan="4">Available Cache</td>
            </tr>
            <tr>
                <th width="40%">Name</th>
                <th width="20%">Keys Count</th>
                <th width="20%">Show Keys</th>
                <th width="20%">Reload Data</th>
            </tr>
            %loop cacheNames%
            %ifvar cacheName matches('MQ*')%
            %else%
            <tr>
                <td style="text-align: left; padding-left: 10px;">%value cacheName%</td>
                <td>%value count%</td>
                <td style="text-align: center;">
                    <a href="keysList.dsp?cacheManagerName=%value cacheManagerName%&cacheName=%value cacheName%" target="keysList">
                        <img src="images/view.png" width="20px" title="Show Keys">
                    </a>
                </td>
                <td style="text-align: center;">
                    <a onclick="confirmReload('%value cacheManagerName%', '%value cacheName%')">
                        <img src="images/reload.png" width="20px" title="Reload Data from Database">
                    </a>
                </td>
            </tr>
            %endif%
            %endloop%
            </table>    
        %else%
        <table id="tblCN" class="tableView" width="100%">
            <tr>
                <td class="heading" colspan="4">Available Cache</td>
            </tr>
            <tr>
                <th width="40%">Name</th>
                <th width="20%">Keys Count</th>
                <th width="20%">Show Keys</th>
            </tr>
            %loop cacheNames%
            %ifvar cacheName matches('MQ*')%
            %else%
            <tr>
                <td style="text-align: left; padding-left: 10px;">%value cacheName%</td>
                <td>%value count%</td>
                <td style="text-align: center;">
                    <a href="keysList.dsp?cacheManagerName=%value cacheManagerName%&cacheName=%value cacheName%" target="keysList">
                        <img src="images/view.png" width="20px" title="Show Keys">
                    </a>
                </td>
            </tr>
            %endif%
            %endloop%
            </table>
    %endif%
%else%
%ifvar cacheManagerName equals('EIPCommonCache')%
<table id="tblCN" class="tableView" width="100%">
            <tr>
                <td class="heading" colspan="4">Available Cache</td>
            </tr>
            <tr>
                <th width="40%">Name</th>
                <th width="20%">Keys Count</th>
                <th width="20%">Show Keys</th>
                <th width="20%">Reload Data</th>
            </tr>
            %loop cacheNames%
            %ifvar cacheName matches('MQ*')%
            %else%
            <tr>
                <td style="text-align: left; padding-left: 10px;">%value cacheName%</td>
                <td>%value count%</td>
                <td style="text-align: center;">
                    <a href="keysList.dsp?cacheManagerName=%value cacheManagerName%&cacheName=%value cacheName%" target="keysList">
                        <img src="images/view.png" width="20px" title="Show Keys">
                    </a>
                </td>
                <td style="text-align: center;">
                    <a class='disabled' disabled>
                        <img src="images/reload.png" width="20px" title="Reload Data from Database">
                    </a>
                </td>
            </tr>
            %endif%
            %endloop%
            </table>    
        %else%
        <table id="tblCN" class="tableView" width="100%">
            <tr>
                <td class="heading" colspan="4">Available Cache</td>
            </tr>
            <tr>
                <th width="40%">Name</th>
                <th width="20%">Keys Count</th>
                <th width="20%">Show Keys</th>
            </tr>
            %loop cacheNames%
            %ifvar cacheName matches('MQ*')%
            %else%
            <tr>
                <td style="text-align: left; padding-left: 10px;">%value cacheName%</td>
                <td>%value count%</td>
                <td style="text-align: center;">
                    <a href="keysList.dsp?cacheManagerName=%value cacheManagerName%&cacheName=%value cacheName%" target="keysList">
                        <img src="images/view.png" width="20px" title="Show Keys">
                    </a>
                </td>
            </tr>
            %endif%
            %endloop%
            </table>
    %endif%
%endinvoke%