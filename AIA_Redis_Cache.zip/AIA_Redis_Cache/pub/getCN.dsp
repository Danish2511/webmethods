<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        const randomVersion = Math.floor(Math.random() * 1000000);
        document.write('<link rel="stylesheet" type="text/css" href="webMethods.css?v=' + randomVersion + '">');
    </script>
</head>

<body>
    <div class="fixed">
        <h2>Cache Names</h2>
    </div>
    <div class="formCN">
        <form id="myForm" action="submitCN.dsp" method="post">
            <div class="select">
                <label>Select Cache Manager:</label>
                <select id="cacheManager" name="cacheManagerName">
                    <option value="">Select</option>
                    %invoke AIA_Redis_Cache.services.dsp:getCacheManagers%
                    %loop cacheManagers%
                    <option value=%value cacheManagers%>%value cacheManagers%</option>
                    %endloop%
                    %endinvoke%
                </select>
            </div>
        </form>
       <table id="tblCN" class="tableView" width="100%">
            <tr>
                <td class="heading" colspan="4">Available Cache</td>
            </tr>
            <tr>
                <th width="40%">Name</th>
                <th width="20%">Keys Count</th>
                <th width="20%">Show Keys</th>
                <th width="20%">Reload Data</th>
            </tr>
            </table>
    </div>
    <script>
        
        const form = document.getElementById('myForm');
		const cn = document.getElementById('cacheManager');

		// Add an event listener to the select element
		cn.addEventListener('change', function () {
			var selectedCN = this.value;
			localStorage.setItem('selectedCN', selectedCN);
			form.submit();
		});

		document.addEventListener('DOMContentLoaded', function () {
			var storedValue = localStorage.getItem('selectedCN');
			if (storedValue) {
				document.getElementById('cacheManager').value = storedValue;
				localStorage.removeItem('selectedCN');
			}
		});

    </script>
</body>

</html>