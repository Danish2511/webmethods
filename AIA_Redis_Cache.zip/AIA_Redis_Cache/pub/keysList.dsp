<html>

<head>
    <script>
        const randomVersion = Math.floor(Math.random() * 1000000);
        document.write('<link rel="stylesheet" type="text/css" href="webMethods.css?v=' + randomVersion + '">');
    </script>
</head>

<body>
    <div id="heading" class="fixed">
        <h2>Cache Keys</h2>
    </div>
    <div class="keysList">
        <table id="myTable" class="tableView" width="100%">
            <thead>
                <tr>
                    <td class="heading" colspan="3">Available Keys</td>
                </tr>
                <tr>
                    <th>Name:&nbsp;&nbsp;<input type="text" id="key" class="filter" data-column="1"
                            placeholder="Search Key"></th>
                    <th colspan="2">View</th>
                </tr>
            </thead>

            %invoke AIA_Redis_Cache.services.dsp:getKeys%
            %loop keys%
            <tbody>
                <tr class="dataRow">
                    <td style="text-align: left; padding-left: 10px; max-width: 50px; word-wrap: break-word;">
                        %value keys%
                    </td>
                    <td style="max-width: 15px; text-align: center;">
                        <a target="keysList">
                            <img src="images/view.png" width="20px" title="Show Value"
                                onclick="showPopup('%value cacheManagerName%','%value cacheName%','%value keys%', true)">
                    </td>
                    %invoke AIA_Redis_Cache.services.dsp:isAdminAccess%
                    %ifvar isAdminAccess equals('true')%
                    <td style="max-width: 15px; text-align: center; display: none">
                        <a target="keysList">
                            <img src="images/edit.png" width="20px" title="Update Value"
                                onclick="showPopup('%value cacheManagerName%','%value cacheName%','%value keys%', false)">
                    </td>
                    %else%
                    <td style="max-width: 15px; text-align: center; display: none">
                        <a class="disabled" disabled>
                            <img src="images/edit.png" width="20px" title="Update Value">
                    </td>
                    %endif%
                    %endinvoke%
                </tr>
            </tbody>
            %endloop%
            %endinvoke%
        </table>
        <div id="popup" class="popup">
            <span class="popup-close" onclick="closePopup()">
                <img src="images/close.png" width="35px" title="Close">
            </span>
            <textarea id="valueTextArea" readonly></textarea>
            <button id="copyButton" class="pill-button"></button>
            <div id="success-message">Successfully Updated</div>
        </div>
        <div id="overlay" class="overlay"></div>
    </div>
    <div id="pagination"></div>
    <script>

        /*********************************** Function to show popup window for displaying key value ******************************/
        function showPopup(cacheManagerName, cacheName, key, readOnly) {
            var cacheManagerName = cacheManagerName;
            var cacheName = cacheName;
            var key = key;

            // Prepare your inputData object
            var inputData = {
                cacheManagerName: cacheManagerName,
                cacheName: cacheName,
                key: key
            };

            // Call the API using fetch
            fetch('/invoke/AIA_Redis_Cache.services.dsp:get', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(inputData),
            })
                .then(response => response.json())
                .then(data => {
                    document.getElementById('valueTextArea').value = data.value;
                })
                .catch(error => {
                    alert('Something went wrong');
                });

            document.getElementById('valueTextArea').readOnly = readOnly;
            // Change button functionality based on readOnly parameter
            var button = document.getElementById('copyButton');
            if (readOnly) {
                button.innerText = 'Copy Value';
                button.setAttribute('onclick', 'copyToClipboard()');
            } else {
                button.innerText = 'Update Value';
                button.setAttribute('onclick', `updateValue('${cacheManagerName}', '${cacheName}', '${key}')`);
            }

            document.getElementById('overlay').style.display = 'block';
            var popup = document.getElementById('popup');
            popup.style.display = 'block';
        }

        /*********************************** Function to call API to update key value ******************************/
        function updateValue(cacheManagerName, cacheName, key) {
            var cacheManagerName = cacheManagerName;
            var cacheName = cacheName;
            var key = key;
            var value = document.getElementById('valueTextArea').value;

            var inputData = {
                cacheManagerName: cacheManagerName,
                cacheName: cacheName,
                key: key,
                value: value
            };

            fetch('/invoke/AIA_Redis_Cache.services.dsp:put', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(inputData),
            })
                .then(response => response.json())
                .then(data => {
                    showSuccessMessage();
                })
                .catch(error => {
                    alert('Something went wrong');
                });
        }

        /*********************************** Function to close popup window ******************************/
        function closePopup() {
            document.getElementById('overlay').style.display = 'none';
            var popup = document.getElementById('popup');
            popup.style.display = 'none';
        }

        /*********************************** Function to copy value ******************************/
        function copyToClipboard() {
            var valueTextArea = document.getElementById('valueTextArea');
            valueTextArea.select();
            document.execCommand('copy');
        }

        /*********************************** Function to show Success message ******************************/
        function showSuccessMessage() {
            var successMessage = document.getElementById('success-message');
            successMessage.style.display = 'block';

            setTimeout(function () {
                successMessage.style.display = 'none';
                location.reload();
            }, 2000);
        }

        /*********************************** Code to generate pagination buttons ******************************/
        var itemsPerPage = 10;
        var totalItems = document.querySelectorAll("#myTable tr.dataRow").length;
        var totalPages = Math.ceil(totalItems / itemsPerPage);

        var currentPage = 1;
        var visiblePageButtons = 2;
        
        /*********************************** Function to display table content based on the current page **********/
        function displayTable() {
            var startIndex = (currentPage - 1) * itemsPerPage;
            var endIndex = startIndex + itemsPerPage;

            var rows = document.getElementById("myTable").getElementsByClassName("dataRow");
            for (var i = 0; i < rows.length; i++) {
                rows[i].style.display = (i >= startIndex && i < endIndex) ? 'table-row' : 'none';
            }
        }

        /*********************************** Function to create pagination buttons **********************************/
        function createPaginationButtons() {
            var paginationDiv = document.getElementById("pagination");
            paginationDiv.innerHTML = ''; // Clear existing buttons

            // Add First button
            var firstButton = document.createElement("button");
            firstButton.innerText = "First";
            firstButton.onclick = function () {
                if (currentPage > 1) {
                    currentPage = 1;
                    displayTable();
                    createPaginationButtons();
                }
            };
            paginationDiv.appendChild(firstButton);

            // Add Previous button
            var prevButton = document.createElement("button");
            prevButton.innerText = "Previous";
            prevButton.onclick = function () {
                if (currentPage > 1) {
                    currentPage--;
                    displayTable();
                    createPaginationButtons();
                }
            };
            paginationDiv.appendChild(prevButton);

            // Add page buttons
            for (var i = Math.max(1, currentPage - Math.floor(visiblePageButtons / 2)); i <= Math.min(totalPages, currentPage + Math.floor(visiblePageButtons / 2)); i++) {
                var pageButton = document.createElement("button");
                pageButton.innerText = i;
                pageButton.onclick = function () {
                    currentPage = parseInt(this.innerText);
                    displayTable();
                    createPaginationButtons();
                };
                if (i === currentPage) {
                    pageButton.style.backgroundColor = "#87027b"; // Highlight the current page
                    pageButton.style.color = "white";
                }
                paginationDiv.appendChild(pageButton);
            }

            // Add Next button
            var nextButton = document.createElement("button");
            nextButton.innerText = "Next";
            nextButton.onclick = function () {
                if (currentPage < totalPages) {
                    currentPage++;
                    displayTable();
                    createPaginationButtons();
                }
            };
            paginationDiv.appendChild(nextButton);

            // Add Last button
            var lastButton = document.createElement("button");
            lastButton.innerText = "Last";
            lastButton.onclick = function () {
                if (currentPage < totalPages) {
                    currentPage = totalPages;
                    displayTable();
                    createPaginationButtons();
                }
            };
            paginationDiv.appendChild(lastButton);
        }

        displayTable();
        createPaginationButtons();

        /*********************************** Function to filter keys from the table *********************************/
        const filterInputs = document.querySelectorAll('.filter');
        filterInputs.forEach(input => {
            input.addEventListener('input', function () {
                const columnIndex = this.dataset.column;
                const filterValue = this.value.toLowerCase();
                const table = document.querySelector('table');
                const rows = table.querySelectorAll('tbody tr');

                rows.forEach(row => {
                    const cell = row.querySelector(`td:nth-child(${parseInt(columnIndex) + 0})`);
                    if (cell) {
                        const cellText = cell.textContent.toLowerCase();
                        if (cellText.includes(filterValue)) {
                            row.style.display = '';
                        } else {
                            row.style.display = 'none';
                        }
                    }
                });
            });
        });
    
    </script>
</body>

</html>