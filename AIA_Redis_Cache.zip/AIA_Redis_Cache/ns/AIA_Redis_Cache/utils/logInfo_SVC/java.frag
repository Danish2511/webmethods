<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">logInfo_SVC</value>
  <value name="encodeutf8">true</value>
  <value name="body">TG9nZ2VyIGxvZ2dlciA9IExvZ2dlci5nZXRMb2dnZXIobG9nSW5mb19TVkNfU1ZDLmNsYXNzKTsN
Cg0KSURhdGFDdXJzb3IgcGlwZWxpbmVDdXJzb3IgPSBwaXBlbGluZS5nZXRDdXJzb3IoKTsNClN0
cmluZwlzdHJNZXNzYWdlID0gSURhdGFVdGlsLmdldFN0cmluZyggcGlwZWxpbmVDdXJzb3IsICJz
dHJNZXNzYWdlIiApOw0KbG9nZ2VyLmluZm8oc3RyTWVzc2FnZSk7DQoNCnBpcGVsaW5lQ3Vyc29y
LmRlc3Ryb3koKTsNCg0KCQ==</value>
</Values>
