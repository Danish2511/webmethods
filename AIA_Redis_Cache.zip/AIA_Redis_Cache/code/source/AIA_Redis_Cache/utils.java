package AIA_Redis_Cache;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.logging.Logger;
import com.wm.lang.ns.*;
import com.wm.app.b2b.server.InvokeState;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataUtil;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void combineLists (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(combineLists)>> ---
		// @sigtype java 3.5
		// [i] field:1:required keys
		// [i] field:1:required values
		// [o] recref:1:required elements AIA_Redis_Cache.docs:keys
		IDataCursor pipelineCursor = pipeline.getCursor();		    
		    // Retrieve input lists
		    String[] keys = IDataUtil.getStringArray(pipelineCursor, "keys");
		    String[] values = IDataUtil.getStringArray(pipelineCursor, "values");	   
		    if (keys == null || values == null || keys.length != values.length) {
		        throw new ServiceException("The input lists must be of equal length and not null.");
		    }
		    IData[] elements = new IData[keys.length];
		    for (int i = 0; i < keys.length; i++) {
		        // Create a new Document (IData) for each key-value pair
		        IData document = IDataFactory.create();
		        IDataCursor docCursor = document.getCursor();
		        IDataUtil.put(docCursor, "key", keys[i]);
		        IDataUtil.put(docCursor, "value", values[i]);
		        docCursor.destroy();
		        elements[i] = document;
		    }
		    IDataUtil.put(pipelineCursor, "elements", elements);
			pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void logInfo_SVC (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(logInfo_SVC)>> ---
		// @sigtype java 3.5
		// [i] field:0:required strMessage
		Logger logger = Logger.getLogger(logInfo_SVC_SVC.class);
		
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	strMessage = IDataUtil.getString( pipelineCursor, "strMessage" );
		logger.info(strMessage);
		
		pipelineCursor.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void writeToFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(writeToFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required fileName
		// [i] field:0:required content
		// [o] field:0:required status
		// pipeline
		  IDataCursor pipelineCursor = pipeline.getCursor();
			String	fileName = IDataUtil.getString( pipelineCursor, "fileName" );
			String	content = IDataUtil.getString( pipelineCursor, "content" );
			String status = "success";
		try {
			Files.write(Paths.get(fileName), content.getBytes());
		} catch (IOException e) {
			status= e.getMessage();
			e.printStackTrace();
		}
		IDataUtil.put( pipelineCursor, "status", status );
		pipelineCursor.destroy();
			
			
		// --- <<IS-END>> ---

                
	}
}

