<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">helloWorld</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgY3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vyc29yKCk7DQovL1N0cmluZyBuYW1l
ID0gSURhdGFVdGlsLmdldFN0cmluZyhjdXJzb3IsICJuYW1lIik7DQpjdXJzb3IuZGVsZXRlKCk7
DQoJU3RyaW5nIG1lc3NhZ2UgPSAiSGVsbG8gRGFuaXNoICEiOw0KCUlEYXRhVXRpbC5wdXQoY3Vy
c29yLCAicmVzdWx0IiwgbWVzc2FnZSk7DQoNCg0KCQ==</value>
</Values>
