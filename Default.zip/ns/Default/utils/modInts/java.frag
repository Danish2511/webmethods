<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">modInts</value>
  <value name="encodeutf8">true</value>
  <value name="body">Ly8gcGlwZWxpbmUNCklEYXRhQ3Vyc29yIHBpcGVsaW5lQ3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vy
c29yKCk7DQoJU3RyaW5nCWEgPSBJRGF0YVV0aWwuZ2V0U3RyaW5nKCBwaXBlbGluZUN1cnNvciwg
ImEiICk7DQoJU3RyaW5nCWIgPSBJRGF0YVV0aWwuZ2V0U3RyaW5nKCBwaXBlbGluZUN1cnNvciwg
ImIiICk7DQoJaW50ICBjID0gSW50ZWdlci5wYXJzZUludChhKSVJbnRlZ2VyLnBhcnNlSW50KGIp
Ow0KSURhdGFVdGlsLnB1dCggcGlwZWxpbmVDdXJzb3IsICJyZXN1bHQiLCBjICk7DQpwaXBlbGlu
ZUN1cnNvci5kZXN0cm95KCk7DQoJ</value>
</Values>
