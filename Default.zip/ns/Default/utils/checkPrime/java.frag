<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">checkPrime</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgYyA9IHBpcGVsaW5lLmdldEN1cnNvcigpOw0KU3RyaW5nIG4gPSBJRGF0YVV0
aWwuZ2V0U3RyaW5nKGMsIm51bSIpOw0KaW50IGZsYWc9MTsNCmJvb2xlYW4gaXNQcmltZTsNCmlu
dCBudW0gPSBJbnRlZ2VyLnBhcnNlSW50KG4pOw0KYy5kZWxldGUoKTsNCmludCBzcXJ0ID0gKGlu
dCkgTWF0aC5zcXJ0KG51bSk7DQpmb3IgKGludCBpPTI7aTw9c3FydDtpKyspDQp7DQoJaW50IHJl
bSA9IG51bSVpOw0KCWlmIChyZW09PTApDQoJew0KCQlmbGFnPTA7DQoJfQ0KfQ0KaWYgKGZsYWc9
PTEpDQp7DQoJaXNQcmltZT10cnVlOw0KfQ0KZWxzZQ0Kew0KCWlzUHJpbWU9ZmFsc2U7DQp9DQpJ
RGF0YVV0aWwucHV0KGMsICJpc1ByaW1lIiwgaXNQcmltZSk7</value>
</Values>
