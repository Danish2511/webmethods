<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">checkEvenOdd</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgY3Vyc29yID0gcGlwZWxpbmUuZ2V0Q3Vyc29yKCk7DQpTdHJpbmcgbiA9IElE
YXRhVXRpbC5nZXRTdHJpbmcoY3Vyc29yLCAibnVtIik7DQppbnQgbnVtID0gSW50ZWdlci5wYXJz
ZUludChuKTsNCmN1cnNvci5kZWxldGUoKTsNCmludCByZW0gPSBudW0lMjsNCmJvb2xlYW4gaXNF
dmVuOw0KaWYgKHJlbT09MCkNCnsNCgkvL0lEYXRhVXRpbC5wdXQoY3Vyc29yLCAicmVzdWx0Iiwg
IlRydWUiKTsNCglpc0V2ZW49dHJ1ZTsNCn0NCmVsc2UNCnsNCgkvL0lEYXRhVXRpbC5wdXQoY3Vy
c29yLCAicmVzdWx0IiwgIk9kZCIpOw0KCWlzRXZlbj1mYWxzZTsNCn0NCklEYXRhVXRpbC5wdXQo
Y3Vyc29yLCAiaXNFdmVuIiwgaXNFdmVuKTs=</value>
</Values>
