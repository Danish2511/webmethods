<?xml version="1.0" encoding="UTF-8"?>

<Values version="2.0">
  <value name="name">getPrimeList</value>
  <value name="encodeutf8">true</value>
  <value name="body">SURhdGFDdXJzb3IgYyA9IHBpcGVsaW5lLmdldEN1cnNvcigpOw0KU3RyaW5nIG4gPSBJRGF0YVV0
aWwuZ2V0U3RyaW5nKGMsICJyYW5nZSIpOw0KaW50IG51bSA9IEludGVnZXIucGFyc2VJbnQobik7
DQpmb3IgKGludCBpPTM7IGk8PW51bTsgaSsrKQ0Kew0KCWZvciAoaW50IGo9Mjsgajw9TWF0aC5z
cXJ0KGkpO2orKykNCgl7DQoJCWlmIChpJWohPTApew0KCQkJSURhdGFVdGlsLnB1dChjLCAicHJp
bWVMaXN0IiwgaSk7DQoJCX0NCgl9DQp9DQoJ</value>
</Values>
