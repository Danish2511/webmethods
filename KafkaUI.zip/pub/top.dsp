<html>

<head>
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
    <meta http-equiv="Expires" content="-1">
    <script>
        const randomVersion = Math.floor(Math.random() * 1000000);
        document.write('<link rel="stylesheet" type="text/css" href="top.css?v=' + randomVersion + '">');
    </script>
</head>

<body>
    <header>
        <img src="images/Apache_Kafka_logo.svg.png" alt="AIA" width="55px" height="55px">
        <div id="content">
            <h1>Kafka Monitor</h1>
        </div>
    </header>
</body>

</html>