<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        const randomVersion = Math.floor(Math.random() * 1000000);
        document.write('<link rel="stylesheet" type="text/css" href="channels.css?v=' + randomVersion + '">');
    </script>
    <script src="scripts.js" defer></script>
</head>

<body>
    <nav id="fixedNav">
        <a href="home.dsp" id="homeLink">Home</a>
        <a href="channels.dsp" id="channelsLink">Channels</a>
        <!--<a onclick="showRow()" id="newButton">New Button</a>-->
    </nav>
    <div id="container">
        <button id="createBtn" onclick="showRow()">Create New Channel</button>
        <table id="interceptor">
            <thead>
                <tr>
                    <th style="width: 15%;">
                        <input type="text" id="chnl" class="filter" data-column="1" placeholder="Search By Channel">
                    </th>
                    <th style="width: 6%;">Delete</th>
                </tr>
            </thead>
            <tr id="hide" style="display: none;">

                <th>
                    <input class="pkgSelect" type="text" name="newChannel" id="channel" placeholder="Enter Channel name"
                        required>
                </th>
                <th>
                    <div class="add-del">
                        <img src="images/add.png" alt="Add" width="25px" title="Add"
                            onclick="validateInputs(document.getElementById('channel').value)">
                        <img src="images/remove.png" alt="Cancel" width="25px" title="Cancel" onclick="hideRow()">
                    </div>
                </th>
            </tr>
            <tbody>
                %invoke AIA_Monitor.v2.services.ui:getChannels%
                %loop channels%
                <tr class="dataRow">
                    <td>%value channels%</td>
                    <td>
                        <div class="add-del">
                            <img id=%value channels% src="images/delete.png" alt="Delete" width="25px" title="Delete"
                                onclick="confirmDelete(this.id)">
                        </div>
                    </td>
                </tr>
                %endloop%
                %endinvoke%
            </tbody>
        </table>
    </div>
    <div id="pagination"></div>

    <script>
        // For Filter Channels
        const filterInputs = document.querySelectorAll('.filter');
        filterInputs.forEach(input => {
            input.addEventListener('input', function () {
                const columnIndex = this.dataset.column;
                const filterValue = this.value.toLowerCase();
                const table = document.querySelector('table');
                const rows = table.querySelectorAll('tbody tr');

                rows.forEach(row => {
                    const cell = row.querySelector(`td:nth-child(${parseInt(columnIndex) + 0})`);
                    if (cell) {
                        const cellText = cell.textContent.toLowerCase();
                        if (cellText.includes(filterValue)) {
                            row.style.display = '';
                        } else {
                            row.style.display = 'none';
                        }
                    }
                });
            });
        });

        function showSuccessMessage() {
            var successMessage = document.getElementById('success-message');
            successMessage.style.display = 'block';

            setTimeout(function () {
                successMessage.style.display = 'none';
                window.location.href = "channels.dsp";
            }, 2000);
        }
        function showDeleteMessage() {
            var deleteMessage = document.getElementById('delete-message');
            deleteMessage.style.display = 'block';

            setTimeout(function () {
                deleteMessage.style.display = 'none';
                window.location.href = "channels.dsp";
            }, 2000);
        }

        function deleteData(channelName) {
            // Retrieve values from all input fields
            var channelName = channelName;

            var inputData = {
                channelName: channelName
            };

            fetch('/invoke/AIA_Monitor.v2.services.ui:removeChannel', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(inputData),
            })
                .then(response => response.json())
                .then(data => {
                    showDeleteMessage();
                })
                .catch(error => {
                    alert('Error:', error);
                });
        }

        function createChannel(newChannel) {
            // Retrieve values from all input fields
            var newChannel = newChannel;

            var inputData = {
                newChannel: newChannel
            };

            fetch('/invoke/AIA_Monitor.v2.services.ui:createChannel', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(inputData),
            })
                .then(response => response.json())
                .then(data => {
                    showSuccessMessage();
                })
                .catch(error => {
                    alert('Error:', error);
                });
        }

        function validateInputs(newChannel) {
            var channelInput = document.getElementById('channel');

            if (channelInput.value.trim() === '') {
                alert('Channel Name is required');
                event.preventDefault();
                return;
            }
            else {
                verifyChannel(newChannel);
            }
        }

        function verifyChannel(newChannel) {
            var inputText = document.getElementById("channel").value;
            var table = document.getElementById("interceptor");
            var found = false;

            // Loop through each row in the table
            for (var i = 1; i < table.rows.length; i++) {
                var cellValue = table.rows[i].cells[0].innerText;

                // Check if the input text matches any value in the table
                if (inputText === cellValue) {
                    found = true;
                    break;
                }
            }

            // Display alert based on whether the value was found or not
            if (found) {
                alert("Channel name already exists");
            } else {
                createChannel(newChannel);
            }
        }
    </script>
    <div id="success-message">
        Saved Successfully
    </div>
    <div id="delete-message">
        Deleted Successfully
    </div>
    <iframe id="hiddenFrame" name="hiddenFrame" style="display: none;"></iframe>
</body>

</html>