<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        const randomVersion = Math.floor(Math.random() * 1000000);
        document.write('<link rel="stylesheet" type="text/css" href="home.css?v=' + randomVersion + '">');
    </script>
    <script src="scripts.js" defer></script>
</head>
<body>
    <nav id="fixedNav">
        <a href="home.dsp" id="homeLink">Home</a>
        <a href="channels.dsp" id="channelsLink">Channels</a>
    </nav>
    <!-- <div id="container">
        <button id="createBtn" onclick="showRow()">Create New Audit</button>
        <table id="interceptor">
            <thead>
                <tr>
                    <th style="width: 7%;">Identifier</th>
                    <th style="width: 15%;">
                        <input type="text" id="pkg" class="filter" data-column="1" placeholder="Search By Package">
                    </th>
                    <th>
                        <input type="text" id="svc" class="filter" data-column="2" placeholder="Search By Service">
                    </th>
                    <th style="width: 10%;">Payload Enabled</th>
                    <th style="width: 15%;">
                        <input type="text" id="chnl" class="filter" data-column="4" placeholder="Search By Channel">
                    </th>
                    <th style="width: 6%;">Delete</th>
                </tr>
            </thead>
            <tr id="hide" style="display: none;">
                <th style="width: 7%;"></th>
                <form id="auditForm" action="/invoke/AIA_Monitor.v2.services:registerForAudit" method="post"
                    target="hiddenFrame">
                    <th style="width: 15%;">
                        <input class="pkgSelect" type="text" name="package" id="package" list="pkgList"
                            placeholder="Enter Package Name" onblur="showServices(this.value)"
                            oninput="showNextTextbox(this, 'service')" required>
                        <datalist id="pkgList">
                            
                            <option value=%value packages%>
                                
                        </datalist>
                    </th>
                    <th>
                        <input class="pkgSelect" type="text" name="service" id="service"
                            placeholder="Enter Service Fully Qualified Name" list="serviceList" style="display: none;">

                        <datalist id="serviceList">

                        </datalist>
                    </th>
                    <th>
                        <select class="pkgSelect" name="payload-flag" id="payload-flag" style="display: none;">
                            <option value="true">true</option>
                            <option value="false">false</option>
                        </select>
                    </th>
                    <th>
                        <input class="pkgSelect" type="text" name="channel" id="channel"
                            placeholder="Enter Channel Name" list="chlList" style="display: none;">
                        <datalist id="chlList">
                            
                            <option value=%value channels%>
                                
                        </datalist>
                    </th>

                </form>
                <th>
                    <div class="add-del">
                        <img src="images/add.png" id="submitButton" alt="Add" width="25px" title="Add">
                        <img src="images/remove.png" alt="Cancel" width="25px" title="Cancel" onclick="hideRow()">
                    </div>
                </th>
            </tr>
            <tbody>
                
                <tr class="dataRow">
                    
                    <td>
                        <div class="add-del">
                            <img id=%value id% src="images/delete.png" alt="Delete" width="25px" title="Delete"
                                onclick="confirmDelete(this.id)">
                        </div>
                    </td>
                </tr>
                
            </tbody>
        </table>
    </div>
    <div id="pagination"></div> -->

    <script>

        /******************************** Filter Services from table ***********************************/

        const filterInputs = document.querySelectorAll('.filter');
        filterInputs.forEach(input => {
            input.addEventListener('input', function () {
                const columnIndex = this.dataset.column;
                const filterValue = this.value.toLowerCase();
                const table = document.querySelector('table');
                const rows = table.querySelectorAll('tbody tr');

                rows.forEach(row => {
                    const cell = row.querySelector(`td:nth-child(${parseInt(columnIndex) + 1})`);
                    if (cell) {
                        const cellText = cell.textContent.toLowerCase();
                        if (cellText.includes(filterValue)) {
                            row.style.display = '';
                        } else {
                            row.style.display = 'none';
                        }
                    }
                });
            });
        });

        /******************************** set Package name based on FQN of service *****************************/

        document.addEventListener('DOMContentLoaded', function () {
            const rows = document.querySelectorAll('tbody tr');
            rows.forEach(function (row) {
                const secondTd = row.querySelector('td:nth-child(2)');
                const thirdTd = row.querySelector('td:nth-child(3)');
                if (secondTd && thirdTd) {
                    const textBeforeDot = thirdTd.textContent.split('.')[0];
                    secondTd.textContent = textBeforeDot;
                }
            });
        });

        /***************** Submit form data to register service with validations *********************/

        const form = document.getElementById('auditForm');
        const submitButton = document.getElementById('submitButton');
        submitButton.addEventListener('click', function () {
            validateInputs();
        });

        /******************** Functions to show Success and Delete message ************************/

        function showSuccessMessage() {
            var successMessage = document.getElementById('success-message');
            successMessage.style.display = 'block';

            setTimeout(function () {
                successMessage.style.display = 'none';
                window.location.href = "home.dsp";
            }, 2000);
        }
        function showDeleteMessage() {
            var deleteMessage = document.getElementById('delete-message');
            deleteMessage.style.display = 'block';

            setTimeout(function () {
                deleteMessage.style.display = 'none';
                window.location.href = "home.dsp";
            }, 2000);
        }

        /***************** Function to delete registered service based on id ***********************/

        function deleteData(id) {
            var id = id;
            var inputData = {
                id: id
            };
            fetch('/invoke/AIA_Monitor.v2.services:removeFromAudit', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(inputData),
            })
                .then(response => response.json())
                .then(data => {
                    showDeleteMessage();
                })
                .catch(error => {
                    alert('Error:', error);
                });
        }

        /******************* Function to validate inputs for not null ********************************/

        function validateInputs() {
            var packageInput = document.getElementById('package');
            var serviceInput = document.getElementById('service');
            var payloadFlagInput = document.getElementById('payload-flag');
            var channelInput = document.getElementById('channel');
            if (packageInput.value.trim() === '') {
                alert('Package Name is required');
            }
            else if (serviceInput.value.trim() === '') {
                alert('Service Fully Qualified Name is required');
            }
            else if (payloadFlagInput.value !== 'true' && payloadFlagInput.value !== 'false') {
                alert('Invalid Payload Flag');
            }
            else if (channelInput.value.trim() === '') {
                alert('Channel is required');
            }
            else {
                verifySvc();
            }
        }

        /********* Function to visibale service text box one after selction of package ***************/

        function showNextTextbox(currentTextbox, nextTextboxId) {
            // Check if an option from the datalist has been selected
            const datalist = document.getElementById(currentTextbox.getAttribute('list'));
            const options = Array.from(datalist.options).map(option => option.value);
            const selectedOption = options.includes(currentTextbox.value);
            const nextTextbox = document.getElementById(nextTextboxId);

            if (selectedOption) {
                nextTextbox.style.display = '';
                document.getElementById("payload-flag").style.display = '';
                document.getElementById("channel").style.display = '';

            } else {
                nextTextbox.style.display = 'none';
                document.getElementById("payload-flag").style.display = 'none';
                document.getElementById("channel").style.display = 'none';
                document.getElementById("payload-flag").value = '';
                document.getElementById("channel").value = '';
                nextTextbox.value = '';
            }
        }

        /******** Function to verify that service is already registered on not ************************/

        function verifySvc() {
            var inputText = document.getElementById("service").value;
            var table = document.getElementById("interceptor");
            var found = false;
            for (var i = 1; i < table.rows.length; i++) {
                var cellValue = table.rows[i].cells[2].innerText;
                if (inputText === cellValue) {
                    found = true;
                    break;
                }
            }
            if (found) {
                alert("Service already registered");
                location.reload();
            } else {
                form.submit();
                showSuccessMessage();
            }
        }

        /******* Code for advanced filtering for services based on given inputs ************************/

        const services = [];
        function showServices(packageName) {
            var packageName = packageName;
            var inputData = {
                packageName: packageName
            };

            fetch('/invoke/AIA_Monitor.v2.services.ui:getAllServices', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(inputData),
            })
                .then(response => response.json())
                .then(data => {
                    services.length = 0;
                    services.push(...data.services);
                    populateDatalist();
                })
                .catch(error => {
                    alert('Error:', error);
                });
        }

        /***** Function to populate list of services as dropdown dynamically based on package name *****/

        function populateDatalist() {
            const sList = document.getElementById("serviceList");
            sList.innerHTML = '';
            services.forEach(service => {
                const option = document.createElement('option');
                option.value = service;
                serviceList.appendChild(option);
            });
        }

        /*************** Function to filter services from dropdown based on input *******************/

        function filterServicesList(input) {
            return services.filter(service =>
                service.toLowerCase().includes(input.toLowerCase())
            );
        }

        /********** Event trigger to call filterServicesList function **********************************/

        document.getElementById("service").addEventListener('input', function () {
            const input = this.value;
            const filteredServicesList = filterServicesList(input);

            // Clear existing options
            document.getElementById("serviceList").innerHTML = '';

            // Populate datalist with filtered countries
            filteredServicesList.forEach(service => {
                const option = document.createElement('option');
                option.value = service;
                document.getElementById("serviceList").appendChild(option);
            });
        });

        /******* Code for advanced filtering for services based on given inputs ************************/
    </script>
    <div id="success-message">
        Saved Successfully
    </div>
    <div id="delete-message">
        Deleted Successfully
    </div>
    <iframe id="hiddenFrame" name="hiddenFrame" style="display: none;"></iframe>
</body>

</html>