<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="menu.css">
</head>
<body>
    <nav>
        <ul>
          <li><a href="topic.dsp" target="mainFrame">Topics</a></li>
            <!-- <li><a href="travelInsurance.dsp" target="mainFrame">Travel Insurance</a></li>
            <li><a href="vehicleInsurance.dsp" target="mainFrame">Vehicle Insurance</a></li>
            <li><a href="viewPolicies.dsp" target="mainFrame">View Policies</a></li> -->
        </ul>
    </nav>
</body>
</html>
