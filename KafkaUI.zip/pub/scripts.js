
//****************************************--For Pagination--***************************************//
var itemsPerPage = 10;
var totalItems = document.querySelectorAll("#interceptor tr.dataRow").length;
var totalPages = Math.ceil(totalItems / itemsPerPage);
// Initialize current page
var currentPage = 1;

// Number of visible page buttons
var visiblePageButtons = 2;

// Function to display table content based on the current page
function displayTable() {
    var startIndex = (currentPage - 1) * itemsPerPage;
    var endIndex = startIndex + itemsPerPage;

    var rows = document.getElementById("interceptor").getElementsByClassName("dataRow");
    for (var i = 0; i < rows.length; i++) {
        rows[i].style.display = (i >= startIndex && i < endIndex) ? 'table-row' : 'none';
    }
}

// Function to generate pagination buttons
function createPaginationButtons() {
    var paginationDiv = document.getElementById("pagination");
    paginationDiv.innerHTML = ''; // Clear existing buttons

    // Add First button
    var firstButton = document.createElement("button");
    firstButton.innerText = "First";
    firstButton.className = "pageBtn";
    firstButton.onclick = function () {
        if (currentPage > 1) {
            currentPage = 1;
            displayTable();
            createPaginationButtons();
        }
    };
    paginationDiv.appendChild(firstButton);

    // Add Previous button
    var prevButton = document.createElement("button");
    prevButton.innerText = "Previous";
    prevButton.className = "pageBtn";
    prevButton.onclick = function () {
        if (currentPage > 1) {
            currentPage--;
            displayTable();
            createPaginationButtons();
        }
    };
    paginationDiv.appendChild(prevButton);

    // Add page buttons
    for (var i = Math.max(1, currentPage - Math.floor(visiblePageButtons / 2)); i <= Math.min(totalPages, currentPage + Math.floor(visiblePageButtons / 2)); i++) {
        var pageButton = document.createElement("button");
        pageButton.innerText = i;
        pageButton.className = "pageBtn";
        pageButton.onclick = function () {
            currentPage = parseInt(this.innerText);
            displayTable();
            createPaginationButtons();
        };
        if (i === currentPage) {
            pageButton.style.backgroundColor = "#d31145"; // Highlight the current page
            pageButton.style.color = "white";
        }
        paginationDiv.appendChild(pageButton);
    }

    // Add Next button
    var nextButton = document.createElement("button");
    nextButton.innerText = "Next";
    nextButton.className = "pageBtn";
    nextButton.onclick = function () {
        if (currentPage < totalPages) {
            currentPage++;
            displayTable();
            createPaginationButtons();
        }
    };
    paginationDiv.appendChild(nextButton);

    // Add Last button
    var lastButton = document.createElement("button");
    lastButton.innerText = "Last";
    lastButton.className = "pageBtn";
    lastButton.onclick = function () {
        if (currentPage < totalPages) {
            currentPage = totalPages;
            displayTable();
            createPaginationButtons();
        }
    };
    paginationDiv.appendChild(lastButton);
}

// Initial setup
displayTable();
createPaginationButtons();
//****************************************--For Pagination--***************************************//

//****************************************--For Scroll to top--***************************************//

function scrollToTop() {
    var scrollableDiv = document.getElementById("container");
    scrollableDiv.scrollTop = 0;
}

//****************************************--For Scroll to top--***************************************//

//****************************************--For Confirm Delete--***************************************//

function confirmDelete(elementId) {
    var confirmation = confirm("Are you sure you want to delete?");
    if (confirmation) {
        deleteData(elementId);
    }
}

//****************************************--For Confirm Delete--***************************************//

//****************************************--For Active Navigation--***************************************//

// JavaScript to set the active class based on the current page or state
document.addEventListener('DOMContentLoaded', function () {
    const currentPath = window.location.pathname;
    const homeLink = document.getElementById('homeLink');
    const channelsLink = document.getElementById('channelsLink');

    if (currentPath.includes("home.dsp")) {
        homeLink.classList.add('active');
    } else if (currentPath.includes("channels.dsp")) {
        channelsLink.classList.add('active');
    }
});

//****************************************--For Active Navigation--***************************************//

//****************************************--For Show and Hide Row--***************************************//

function showRow() {
    var row = document.getElementById("hide"); // Change the index to the row you want to toggle
    row.style.display = "table-row";
    scrollToTop();
}
function hideRow() {
    location.reload();
}

//****************************************--For Show and Hide Row--***************************************//
