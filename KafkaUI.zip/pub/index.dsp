<html>
<head>
   <title>Kafka Monitoring</title>
   <link REL="SHORTCUT ICON" href="images/favicon.ico">
   <frameset rows="12%,*" frameborder="0">
      <frame src="top.dsp" noresize>
         <frameset cols="15%,*" frameborder="0">
            <frame src="menu.dsp" scrolling="no" noresize>
               <frame src="home.dsp" name="mainFrame" noresize>
        </frameset>
   </frameset>
</head>
</html>